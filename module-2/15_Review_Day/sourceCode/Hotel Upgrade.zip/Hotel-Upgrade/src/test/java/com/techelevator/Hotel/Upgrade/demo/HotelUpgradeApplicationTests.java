package com.techelevator.Hotel.Upgrade.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelUpgradeApplicationTests {

	@Test
	void contextLoads() {
	}

}
