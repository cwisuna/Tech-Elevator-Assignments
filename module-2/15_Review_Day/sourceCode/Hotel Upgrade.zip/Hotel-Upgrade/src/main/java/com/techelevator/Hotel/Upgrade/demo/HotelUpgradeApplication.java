package com.techelevator.Hotel.Upgrade.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelUpgradeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelUpgradeApplication.class, args);
	}

}
