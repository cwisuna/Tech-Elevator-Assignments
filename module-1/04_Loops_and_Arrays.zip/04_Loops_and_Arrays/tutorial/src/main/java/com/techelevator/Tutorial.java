package com.techelevator;

public class Tutorial {

    public static void main(String[] args) {
//        int i;
//        for ( i = 0; i <= 5; i ++) {
//            System.out.println(i);
//        } for (i = 10; i >= 0; i--) {
//            System.out.println(i);
//        }
        int[] forecastTemperatures = new int[5];
        forecastTemperatures[0] = 72;
        forecastTemperatures[1] = 78;
        forecastTemperatures[2] += 10;
        forecastTemperatures[3] = 79;
        forecastTemperatures[4] = 74;

            System.out.println(forecastTemperatures[2]);
        }
    }
}
